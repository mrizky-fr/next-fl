@echo off
rem Use when NextFL.exe is blocked
cd /d "%~dp0"
start "" "%~dp0runtime\bin\javaw.exe" -Djpackage.app-version="1.0.66" -Dcompose.application.resources.dir="%~dp0app\resources" -Dcompose.application.configure.swing.globals="true" -Dnextfl.version="0.1.66" -Dskiko.library.path="%~dp0app" @app\launcher.args %*
